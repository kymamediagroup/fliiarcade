These samples are from retrocade.
